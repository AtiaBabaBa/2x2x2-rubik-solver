void guide2(int n)
{
	printf("----------------------\n");
			printf("|                    |\n");
			printf("| 2x2x2 Rubik solver |\n");
			printf("|                    |\n");
			printf("----------------------\n\n");	
			printf("Please input each color follow the number of faces and the following order.\n");
	printf("       _______\n");
	printf("       |     |\n");
	printf("       |  5  |\n");
	printf("_______|_____|______ ______\n");
	printf("|      |     |      |      |\n");
	printf("|  4   |  1  |  2   |  3   |\n");
	printf("|______|_____|______|______|\n");
	printf("       |     |\n");
	printf("       |  6  |\n");
	printf("       |_____|\n");
	printf("\n");
	printf("      ____ ____ \n");
	printf("     |    |    | \n");
	printf("     | a  |  b | \n");
	printf("     |____|____| \n");
	printf("     |    |    | \n");
	printf("     | c  |  d | \n");
	printf("     |____|____| \n");
	printf("\nY for Yellow, G for Green, R for Red, W for White, O for Orange, B for Blue\n\n");
}
/*void showbikbase(char rubik[6][3][3])
{
	printf("         ___ ___\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[3][0][1],rubik[3][0][0]);
	printf("        |___|___|\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[3][1][1],rubik[3][1][0]);
	printf(" ___ ___|___|___|___ ___ ___ ___\n");
	printf("|   |   |   |   |   |   |   |   |\n");
	printf("| %c | %c | %c | %c | %c | %c | %c | %c |\n",rubik[4][0][0],rubik[4][1][0],rubik[0][1][0],rubik[0][1][1],rubik[2][0][1],rubik[2][1][1],rubik[5][0][1],rubik[5][0][0]);
	printf("|___|___|___|___|___|___|___|___|\n");
	printf("|   |   |   |   |   |   |   |   |\n");
	printf("| %c | %c | %c | %c | %c | %c | %c | %c |\n",rubik[4][0][1],rubik[4][1][1],rubik[0][0][0],rubik[0][0][1],rubik[2][0][0],rubik[2][1][0],rubik[5][1][1],rubik[5][1][0]);
	printf("|___|___|___|___|___|___|___|___|\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[1][1][0],rubik[1][1][1]);
	printf("        |___|___|\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[1][0][0],rubik[1][0][1]);
	printf("        |___|___|\n");
}*/
void showbik(char rubik[6][3][3])
{
	printf("         ___ ___\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[4][0][0],rubik[4][0][1]);
	printf("        |___|___|\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[4][1][0],rubik[4][1][1]);
	printf(" ___ ___|___|___|___ ___ ___ ___\n");
	printf("|   |   |   |   |   |   |   |   |\n");
	printf("| %c | %c | %c | %c | %c | %c | %c | %c |\n",rubik[3][0][0],rubik[3][0][1],rubik[0][0][0],rubik[0][0][1],rubik[1][0][0],rubik[1][0][1],rubik[2][0][0],rubik[2][0][1]);
	printf("|___|___|___|___|___|___|___|___|\n");
	printf("|   |   |   |   |   |   |   |   |\n");
	printf("| %c | %c | %c | %c | %c | %c | %c | %c |\n",rubik[3][1][0],rubik[3][1][1],rubik[0][1][0],rubik[0][1][1],rubik[1][1][0],rubik[1][1][1],rubik[2][1][0],rubik[2][1][1]);
	printf("|___|___|___|___|___|___|___|___|\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[5][0][0],rubik[5][0][1]);
	printf("        |___|___|\n");
	printf("        |   |   |\n");
	printf("        | %c | %c |\n",rubik[5][1][0],rubik[5][1][1]);
	printf("        |___|___|\n");
}
void guideDirection(int n)
{
	
	//printf("R! for right up\n");
	printf("L for left down\n");printf("L! for left up\n");
	//printf("L! for left up\n");
	printf("U for up counter clockwise\n");
//	printf("U! for up clockwise\n");
	printf("U! for up clockwise\n");
	//printf("D! for down counter clockwise\n");
	printf("F for front clockwise\n");
	//printf("F! for front counter clockwise\n");
	printf("F! for front counter clockwise\n");
//	printf("B! for back clockwise\n");
}
void thank(int n)
{
	printf("\n\n\n\n\n\n\n\n\n");
	printf("                        ==================================================================\n\n");
	printf("                                       THANK YOU FOR USING OUR PROGRAM.\n");
	printf("                                             SEE YOU AGAIN HONEY.\n");
	printf("                                                   BYE <3\n");
	printf("                                             I LOVE YOU 40404!!\n\n");
	printf("                        ==================================================================\n\n");
}
void play(int n)
{
	printf("Do you want to try it by yourself or use me for solve it?(1 for try it by yourself, 2 for bot solving)\n");
}
