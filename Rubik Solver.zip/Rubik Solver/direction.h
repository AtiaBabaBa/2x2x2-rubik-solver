void spin(char move[5],char rubik[6][3][3])
{
	if(move[0]=='L')
	{
			char s;
			s=rubik[4][0][0];
			rubik[4][0][0]=rubik[2][1][1];
			rubik[2][1][1]=rubik[5][0][0];
			rubik[5][0][0]=rubik[0][0][0];
			rubik[0][0][0]=s;
			s=rubik[4][1][0];
			rubik[4][1][0]=rubik[2][0][1];
			rubik[2][0][1]=rubik[5][1][0];
			rubik[5][1][0]=rubik[0][1][0];
			rubik[0][1][0]=s;
			s=rubik[3][0][0];
			rubik[3][0][0]=rubik[3][1][0];
			rubik[3][1][0]=rubik[3][1][1];
			rubik[3][1][1]=rubik[3][0][1];
			rubik[3][0][1]=s;
	}
	/*else if(move[0]=='R')
	{
			char s;
			s=rubik[4][0][1];
			rubik[4][0][1]=rubik[0][0][1];
			rubik[0][0][1]=rubik[5][0][1];
			rubik[5][0][1]=rubik[2][1][0];
			rubik[2][1][0]=s;
			s=rubik[4][1][1];
			rubik[4][1][1]=rubik[0][1][1];
			rubik[0][1][1]=rubik[5][1][1];
			rubik[5][1][1]=rubik[2][0][0];
			rubik[2][0][0]=s;
			s=rubik[1][0][0];
			rubik[1][0][0]=rubik[1][1][0];
			rubik[1][1][0]=rubik[1][1][1];
			rubik[1][1][1]=rubik[1][0][1];
			rubik[1][0][1]=s;
	}*/
	else if(move[0]=='F')
	{
			char s;
			s=rubik[4][1][0];
			rubik[4][1][0]=rubik[3][1][1];
			rubik[3][1][1]=rubik[5][0][1];
			rubik[5][0][1]=rubik[1][0][0];
			rubik[1][0][0]=s;
			s=rubik[4][1][1];
			rubik[4][1][1]=rubik[3][0][1];
			rubik[3][0][1]=rubik[5][0][0];
			rubik[5][0][0]=rubik[1][1][0];
			rubik[1][1][0]=s;
			s=rubik[0][0][0];
			rubik[0][0][0]=rubik[0][1][0];
			rubik[0][1][0]=rubik[0][1][1];
			rubik[0][1][1]=rubik[0][0][1];
			rubik[0][0][1]=s;
	}
	/*else if(move[0]=='B')
	{
			char s;
			s=rubik[4][0][0];
			rubik[4][0][0]=rubik[1][0][1];
			rubik[1][0][1]=rubik[5][1][1];
			rubik[5][1][1]=rubik[3][1][0];
			rubik[3][1][0]=s;
			s=rubik[4][0][1];
			rubik[4][0][1]=rubik[1][1][1];
			rubik[1][1][1]=rubik[5][1][0];
			rubik[5][1][0]=rubik[3][0][0];
			rubik[3][0][0]=s;
			s=rubik[2][0][0];
			rubik[2][0][0]=rubik[2][1][0];
			rubik[2][1][0]=rubik[2][1][1];
			rubik[2][1][1]=rubik[2][0][1];
			rubik[2][0][1]=s;
	}*/
	else if(move[0]=='U')
	{
		char s;
		s=rubik[3][0][0];
		rubik[3][0][0]=rubik[2][0][0];
		rubik[2][0][0]=rubik[1][0][0];
		rubik[1][0][0]=rubik[0][0][0];
		rubik[0][0][0]=s;
		s=rubik[3][0][1];
		rubik[3][0][1]=rubik[2][0][1];
		rubik[2][0][1]=rubik[1][0][1];
		rubik[1][0][1]=rubik[0][0][1];
		rubik[0][0][1]=s;
		s=rubik[4][0][0];
		rubik[4][0][0]=rubik[4][0][1];
		rubik[4][0][1]=rubik[4][1][1];
		rubik[4][1][1]=rubik[4][1][0];
		rubik[4][1][0]=s;
	}
	/*else if(move[0]=='D')
	{
		char s;
		s=rubik[3][1][0];
		rubik[3][1][0]=rubik[0][1][0];
		rubik[0][1][0]=rubik[1][1][0];
		rubik[1][1][0]=rubik[2][1][0];
		rubik[2][1][0]=s;
		s=rubik[3][1][1];
		rubik[3][1][1]=rubik[0][1][1];
		rubik[0][1][1]=rubik[1][1][1];
		rubik[1][1][1]=rubik[2][1][1];
		rubik[2][1][1]=s;
		s=rubik[5][0][0];
		rubik[5][0][0]=rubik[5][0][1];
		rubik[5][0][1]=rubik[5][1][1];
		rubik[5][1][1]=rubik[5][1][0];
		rubik[5][1][0]=s;
	}*/
	else if(move[0]=='R')
	{
		spin("L",rubik);
		spin("L",rubik);
		spin("L",rubik);
	}
	else if(move[0]=='B')
	{
		spin("F",rubik);
		spin("F",rubik);
		spin("F",rubik);
	}
	else if(move[0]=='D')
	{
		spin("U",rubik);
		spin("U",rubik);
		spin("U",rubik);
	}
}
 /*    _______
       |     |
       |  4  |
 ______|_____|______ ______
|      |     |      |      |
|   5  |  1  |  3   |  6   |
|______|_____|______|______|
       |     |
       |  2  |
       |_____| */
