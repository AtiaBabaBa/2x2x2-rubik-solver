int sukoi=0;
int check(char rubik[6][3][3])
{
	if(rubik[0][0][0]==rubik[0][0][1]&&rubik[0][0][0]==rubik[0][1][0]&&rubik[0][0][0]==rubik[0][1][1])
	{
		if(rubik[1][0][0]==rubik[1][0][1]&&rubik[1][0][0]==rubik[1][1][0]&&rubik[1][0][0]==rubik[1][1][1])
		{
		if(rubik[2][0][0]==rubik[2][0][1]&&rubik[2][0][0]==rubik[2][1][0]&&rubik[2][0][0]==rubik[2][1][1])
		{if(rubik[3][0][0]==rubik[3][0][1]&&rubik[3][0][0]==rubik[3][1][0]&&rubik[3][0][0]==rubik[3][1][1])
		{
			if(rubik[4][0][0]==rubik[4][0][1]&&rubik[4][0][0]==rubik[4][1][0]&&rubik[4][0][0]==rubik[4][1][1])
			{
					if(rubik[5][0][0]==rubik[5][0][1]&&rubik[5][0][0]==rubik[5][1][0]&&rubik[5][0][0]==rubik[5][1][1])
					{
						return 1;
					}
			}
	
		}
		
		}
		
	}
	}
}
int palin(char st[12])
{
	int l=strlen(st)-1;
	for(int i=0;i<l/2;i++)
	{
		if(st[i]!=st[l-i])
		{
			return 0;
		}
	}
	return 1;
}
void brute(int n,int l,int r,int f,int b,int u,int d,char ss[11],char crubik[6][3][3])
{
	if(sukoi==1) return;
	char rubik[6][3][3],st[11];
	//printf("%d\n",n);
	strcpy(st,ss);
	for(int i=0;i<6;i++)
	{
		for(int j=0;j<3;j++)
		{
			for(int k=0;k<3;k++)
			{
				rubik[i][j][k]=crubik[i][j][k];
			}
		}
	}
	//showbik(rubik);
	//printf("%s\n",st);
	//printf("%s\n",st);
	if(check(rubik)==1)
		{
			for(int x=0;x<=n;x++)
			{
				if(st[x]=='L') printf("L ",st[x]);
				else if(st[x]=='R') printf("L! ",st[x]);
				else if(st[x]=='U') printf("U ",st[x]);
				else if(st[x]=='D') printf("U! ",st[x]);
				else if(st[x]=='F') printf("F ",st[x]);
				else if(st[x]=='B') printf("F! ",st[x]);
			}
			printf("\n\n\n");
			showbik(rubik);
			for(unsigned long long int qw=0;qw<111111111111111;qw++)
			{
				//printf("%s\n",st);
				printf("\n\n\n");
				system("pause");
				sukoi=1;
				return;
				
			}
		}
	if(n>=12)
	{
		/*if(l==1)
		{
			printf("YEL\n");
			spin("R",rubik);
		}
		else if(r==1)
		{
			printf("YER\n");
			spin("L",rubik);
		}
		else if(f==1)
		{
			printf("YEF\n");
			spin("B",rubik);
		}
		else if(b==1)
		{
			printf("YEB\n");
			spin("F",rubik);
		}
		else if(u==1)
		{
			printf("YEU\n");
			spin("D",rubik);
		}
		else if(d==1)
		{
			printf("YED\n");
			spin("U",rubik);
		}*/
		return;
	}
	int len=strlen(st);
	if(len>=4&&palin(st)==1)
	{
		return;
	}
	if(n==0)
	{
		spin("L",rubik);
		st[n]='L';
		brute(1,1,0,0,0,0,0,st,rubik);
		spin("L",rubik);
		spin("L",rubik);
		spin("L",rubik);
		//printf("1 process(es) succeed.\n");
	}if(sukoi==1) return;
	else 
	if(n==0)
	{
		spin("R",rubik);
		st[n]='R';
		brute(1,0,1,0,0,0,0,st,rubik);
		spin("R",rubik);
		spin("R",rubik);
		spin("R",rubik);
		//printf("2 process(es) succeed.\n");
	}if(sukoi==1) return;
	if(n==0)
	{
		spin("F",rubik);
		st[n]='F';
		brute(1,0,0,1,0,0,0,st,rubik);
		spin("F",rubik);
		spin("F",rubik);
		spin("F",rubik);
		//printf("3 process(es) succeed.\n");
	}if(sukoi==1) return;
	if(n==0)
	{
		spin("B",rubik);
		st[n]='B';
		brute(1,0,0,0,1,0,0,st,rubik);
		spin("B",rubik);
		spin("B",rubik);
		spin("B",rubik);
	//	printf("4 process(es) succeed.\n");
	}if(sukoi==1) return;
	if(n==0)
	{
		spin("U",rubik);
		st[n]='U';
		brute(1,0,0,0,0,1,0,st,rubik);
		spin("U",rubik);
		spin("U",rubik);
		spin("U",rubik);
		//printf("5 process(es) succeed.\n");
	}if(sukoi==1) return;
	if(n==0)
	{
		spin("D",rubik);
		st[n]='D';
		brute(1,0,0,0,0,0,1,st,rubik);
		spin("D",rubik);
		spin("D",rubik);
		spin("D",rubik);
	//	printf("6 process(es) succeed.\n");
		printf("Your rubik problem is impossible. Don't try to kidding me honey.\n");
		system("pause");
	}if(sukoi==1) return;
	
	if(n!=0)
	{
		if(st[n-1]!='R')
		{
			if(n>=2)
			{
				if(st[n-1]=='L'&&st[n-2]=='L')
				{
					
				}
				else
				{
					spin("L",rubik);
					st[n]='L';
					brute(n+1,1,0,0,0,0,0,st,rubik);
					spin("L",rubik);
					spin("L",rubik);spin("L",rubik);
				}
			}
			else
			{
				spin("L",rubik);
				st[n]='L';
				brute(n+1,1,0,0,0,0,0,st,rubik);
				spin("L",rubik);spin("L",rubik);spin("L",rubik);
			}		
		}
		if(st[n-1]!='L')
		{
			if(n>=2)
			{
				if(st[n-1]=='R'&&st[n-2]=='R')
				{
					
				}
				else
				{
					spin("R",rubik);
					st[n]='R';
					brute(n+1,0,1,0,0,0,0,st,rubik);
					spin("R",rubik);spin("R",rubik);spin("R",rubik);
				}
			}
			else
			{
				spin("R",rubik);
				st[n]='R';
				brute(n+1,0,1,0,0,0,0,st,rubik);
				spin("R",rubik);spin("R",rubik);spin("R",rubik);
			}		
		}
		if(st[n-1]!='B')
		{
			if(n>=2)
			{
				if(st[n-1]=='F'&&st[n-2]=='F')
				{
					
				}
				else
				{
					spin("F",rubik);
					st[n]='F';
					brute(n+1,0,0,1,0,0,0,st,rubik);
					spin("F",rubik);spin("F",rubik);spin("F",rubik);
				}
			}
			else
			{
				spin("F",rubik);
				st[n]='F';
				brute(n+1,0,0,1,0,0,0,st,rubik);
				spin("F",rubik);spin("F",rubik);spin("F",rubik);
			}		
		}
		if(st[n-1]!='F')
		{
			if(n>=2)
			{
				if(st[n-1]=='B'&&st[n-2]=='B')
				{
					
				}
				else
				{
					spin("B",rubik);
					st[n]='B';
					brute(n+1,0,0,0,1,0,0,st,rubik);
					spin("B",rubik);spin("B",rubik);spin("B",rubik);
				}
			}
			else
			{
				spin("B",rubik);
				st[n]='B';
				brute(n+1,0,0,0,1,0,0,st,rubik);
				spin("B",rubik);spin("B",rubik);spin("B",rubik);
			}		
		}
		if(st[n-1]!='U')
		{
			if(n>=2)
			{
				if(st[n-1]=='D'&&st[n-2]=='D')
				{
					
				}
				else
				{
					spin("D",rubik);
					st[n]='D';
					brute(n+1,0,0,0,0,1,0,st,rubik);
					spin("D",rubik);spin("D",rubik);spin("D",rubik);
				}
			}
			else
			{
				spin("D",rubik);
				st[n]='D';
				brute(n+1,0,0,0,0,1,0,st,rubik);
				spin("D",rubik);spin("D",rubik);spin("D",rubik);
			}		
		}
		if(st[n-1]!='D')
		{
			if(n>=2)
			{
				if(st[n-1]=='U'&&st[n-2]=='U')
				{
					
				}
				else
				{
					spin("U",rubik);
					st[n]='U';
					brute(n+1,0,0,0,0,0,1,st,rubik);
					spin("U",rubik);spin("U",rubik);spin("U",rubik);
				}
			}
			else
			{
				spin("U",rubik);
				st[n]='U';
				brute(n+1,0,0,0,0,0,1,st,rubik);
				spin("U",rubik);spin("U",rubik);spin("U",rubik);
			}		
		}
		
	}
	
	//printf("Finish case L\n");
	return ;
}
void solve(char rubik[6][3][3])
{
	char crubik[6][3][3],st[12];
	for(int i=0;i<6;i++)
	{
		for(int j=0;j<3;j++)
		{
			for(int k=0;k<3;k++)
			{
				crubik[i][j][k]=rubik[i][j][k];
			}
		}
	}
	brute(0,0,0,0,0,0,0,st,crubik);	
}
