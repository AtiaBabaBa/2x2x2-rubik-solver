#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<conio.h>
#include"guide.h"
#include"direction.h"
#include"system.h"
int main()
{
	printf("Welcome to Rubrik Solver!!!\n\nWhich size of rubik that you want to solve?\nPress 1 For 2*2*2\nPress 2 For 3*3*3\n");
	int com;
	while(1)
	{
		com=getch();
		if(com==49)
		{
			char rubik[6][3][3];
			system("CLS");
			system("color 70");
			guide2(2);
			/*input*/
			for(int i=0;i<6;i++)
			{
				for(int j=0;j<2;j++)
				{
					for(int k=0;k<2;k++)
					{
						scanf(" %c",&rubik[i][j][k]);	
					}	
				}	
				printf("%d face(s) success\n",i+1);
			}
			showbik(rubik);
			guideDirection(2);
			play(2);
			//printf("\n");
			int select;
			printf("Choose: ");
			scanf(" %d",&select);
			printf("\n");
			if(select==1)
			{
			printf("Press space bar to type your move or Press Enter to let the computer solving.\n");
				while(com!=13)
				{
					if(com==13)
					{
						
					}
					else
					{
						com=getch();
						if(com==13)
					{
						
					}
					else
					{
						char spinn[5];
					printf("Your move: ");
					scanf(" %s",spinn);
					spin(spinn,rubik);
					showbik(rubik);
					if(check(rubik)==1)
					{
						printf("WOW!!! You can solve it. Thank you for using rubik solver.\n");
						system("pause");
						system("cls");
						thank(2);
			printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			return 0;
					}
					printf("Press space bar to type your move or Press Enter to let the computer solving.\n");
					}
					
					}
					
				}
				select=2;
			}
			if(select==2)
			{
				printf("When you do follow the program. Please put 2nd side of rubik in front of your face.\n");
			//spin("L",rubik);
			//spin("R",rubik);
			//showbik(rubik);
			//showbik(rubik);
			//printf("%d\n",palin("helleh"));
			printf("Solving. . .\n");
			solve(rubik);
			system("cls");
			thank(2);
			printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			return 0;
			}
			
		}
		else if(com==50)
		{
			system("color 17");
			system("CLS");
			printf("\n\t\t\tComing Soon...\n\t\t\tSo, press 1\n");
		}
		else
		{
			
		}
	}	
}
